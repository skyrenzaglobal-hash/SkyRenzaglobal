SKYRENZA Website
=================

Files:
- index.html — complete responsive website
- assets/skyrenza-founder-banner.png — SKYRENZA founder banner

Contact:
- Email: skyrenzaglobal@gmail.com
- Founder: Abhijit Kale

To publish:
1. Open index.html in a browser to preview.
2. Upload the files to your chosen hosting provider, or use the HTML as the design/content reference for Google Sites.
3. Replace/add a phone number only when you have a dedicated business number.
