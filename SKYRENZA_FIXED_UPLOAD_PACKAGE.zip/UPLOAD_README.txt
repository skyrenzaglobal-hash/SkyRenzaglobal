SKYRENZA — FIXED WEBSITE UPLOAD PACKAGE

This package fixes the image-path / image-format mismatch in the previous package. The previous founder files were named .png even though their actual file format was JPEG. This version converts them to genuine .jpg files and updates every HTML reference.

IMPORTANT: All website files are at the ZIP ROOT. There is NO enclosing website folder and NO assets folder.

FILES TO UPLOAD TO THE ROOT OF YOUR EXISTING REPOSITORY:
- index.html
- about.html
- services.html
- industries.html
- contact.html
- styles.css
- pages.css
- script.js
- skyrenza-logo.jpg
- founder-speaking.jpg
- founder-standing.jpg
- founder-office.jpg
- office-interior.jpg
- company-values.jpg
- favicon.svg

HOW TO UPDATE:
1. Open https://github.com/skyrenzaglobal-hash/SkyRenzaglobal
2. Use Add file > Upload files. Upload the files listed above together into the repository ROOT (not inside another folder).
3. Commit changes to the main branch.
4. Wait for GitHub Pages to publish. Open https://skyrenzaglobal-hash.github.io/SkyRenzaglobal/ and refresh.

Contact: skyrenzaglobal@gmail.com | +91 62394 96472

The “Ask SKYRENZA” widget is a front-end FAQ demo, not a connected live AI model. Contact form opens the visitor’s email app; it does not store submissions on a server.
